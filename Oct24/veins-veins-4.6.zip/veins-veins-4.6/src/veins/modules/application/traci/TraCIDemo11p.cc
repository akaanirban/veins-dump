//
// Copyright (C) 2006-2011 Christoph Sommer <christoph.sommer@uibk.ac.at>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "veins/modules/application/traci/TraCIDemo11p.h"
#include <string>
#include "veins/modules/mobility/traci/TraCIScenarioManager.h"
#include "veins/modules/mobility/traci/TraCICommandInterface.h"


using namespace std;

Define_Module(TraCIDemo11p);

void TraCIDemo11p::initialize(int stage) {
    BaseWaveApplLayer::initialize(stage);
    if (stage == 0) {
        sentMessage = false;
        lastDroveAt = simTime();
        currentSubscribedServiceId = -1;
    }
    //mobility = TraCIMobilityAccess().get(mobility);
    cout << "Vehicle: "<< mobility->getExternalId() << endl;
    cout << stage <<endl; //the stage value is 0 / 1 and gets executed twice ??!???!??
    WaveShortMessage* wsm = new WaveShortMessage();  //Updated sim code
    populateWSM(wsm, 0, 0, "Go Bobcats!");  //create variable to customize message?
    wsm->setPsid(-10);
    //scheduleAt(simTime() + 1 + uniform(0.01,0.2), wsm);  //create variable to customize delay?
    scheduleAt(simTime() + 1, wsm);  //create variable to customize delay?

}

void TraCIDemo11p::onWSA(WaveServiceAdvertisment* wsa) {
    if (currentSubscribedServiceId == -1) {
        mac->changeServiceChannel(wsa->getTargetChannel());
        currentSubscribedServiceId = wsa->getPsid();
        if  (currentOfferedServiceId != wsa->getPsid()) {
            stopService();
            startService((Channels::ChannelNumber) wsa->getTargetChannel(), wsa->getPsid(), "Mirrored Traffic Service");
        }
    }
}

void TraCIDemo11p::onWSM(WaveShortMessage* wsm) {

    findHost()->getDisplayString().updateWith("r=16,green");
    if (mobility->getRoadId()[0] != ':') traciVehicle->changeRoute(wsm->getWsmData(), 9999);
    if (!sentMessage) {
        sentMessage = true;
        //repeat the received traffic update once in 2 seconds plus some random delay
        wsm->setSenderAddress(myId);
        wsm->setSerial(3);
        scheduleAt(simTime() + 2 + uniform(0.01,0.2), wsm->dup());
    }

}

void TraCIDemo11p::onCWSM(WaveShortMessage* wsm) {  //Updated sim code, custom method to handle receiving a "custom wave short message".  This only prints out the message when received at this time
    cout << "DATA:----->"<<wsm->getWsmData()  << " " << receivedCWSMs <<  endl;  //" "  <<  wsm->getDefaultOwner() <<
    //cout << wsm->getOwner()<< " "<< wsm->getSenderAddress()<< " "<< wsm->getRecipientAddress() << " "<< wsm->getFullPath() <<endl;
    //cout <<  wsm->getDefaultOwner()->getDescriptor() << this->getFullName()<< " gen WSM:"<<wsm->getSenderModule() << "--"<< wsm->getRecipientAddress()<< endl;
    //MessageList.push_back(wsm->getWsmData());
    ofstream myfile ("example.txt", std::ofstream::app);
      if (myfile.is_open())
      {
        mobility = TraCIMobilityAccess().get(getParentModule());
        traci = mobility->getCommandInterface();
        traciVehicle = mobility->getVehicleCommandInterface();
        myfile<<"Vehicle ID: ";
        myfile<< mobility->getExternalId();
        myfile << " Data:" << wsm->getWsmData()<< "\n";
        //int index = mobility->getIndex();
        //myfile<< mobility->getParentModule()->getSubmodule("Nic80211p", index+2)->getSubmodule("Mac1609_4", index+5)->getProperties();
        myfile.close();
      }
}

void TraCIDemo11p::handleSelfMsg(cMessage* msg) {

    if (WaveShortMessage* wsm = dynamic_cast<WaveShortMessage*>(msg)) {
        cout<<wsm->getWsmData()<<"-------------------"<<endl;
        sendDown(wsm->dup());
        wsm->setSerial(wsm->getSerial() +1);

        if (wsm->getWsmData() != NULL) {
            sendDown(wsm->dup());
            scheduleAt(simTime()+1, wsm);
        }
        //send this message on the service channel until the counter is 3 or higher.
        //this code only runs when channel switching is enabled
        else if (wsm->getSerial() >= 3) {
            //stop service advertisements
            stopService();
            delete(wsm);
        }
        else {
            scheduleAt(simTime()+1, wsm);
        }
    }
    else {
            BaseWaveApplLayer::handleSelfMsg(msg);
    }
}

void TraCIDemo11p::handlePositionUpdate(cObject* obj) {
    BaseWaveApplLayer::handlePositionUpdate(obj);

    // stopped for for at least 1s?
    if (mobility->getSpeed() < 1) {
        if (simTime() - lastDroveAt >= 1 && sentMessage == false) {
            findHost()->getDisplayString().updateWith("r=16,red");
            sentMessage = true;

            WaveShortMessage* wsm = new WaveShortMessage();
            populateWSM(wsm);
            wsm->setWsmData(mobility->getRoadId().c_str());

            //host is standing still due to crash
            if (dataOnSch) {
                startService(Channels::SCH2, 42, "Traffic Information Service");
                //started service and server advertising, schedule message to self to send later
                scheduleAt(computeAsynchronousSendingTime(1,type_SCH),wsm);
            }
            else {
                //send right away on CCH, because channel switching is disabled
                sendDown(wsm);
            }
        }
    }
    else {
        lastDroveAt = simTime();
    }
}

void TraCIDemo11p::writeMessages(){  //anirban code
    /*//char filename[64];
    mobility = TraCIMobilityAccess().get(getParentModule());
    //sprintf (filename, "messages_%d.txt", mobility->getExternalId());
    std::ostringstream filenameStream;
    filenameStream << "testresults/messages_" << mobility->getExternalId() << ".txt";
    std::string filename = filenameStream.str();
    //char *path="/home/user/"+filename;
    //ofstream newfile (path);
    ofstream newfile (filename);
    cout<< "Car"<<mobility->getExternalId()<<MessageList.size()<<endl;
    for (string &s : MessageList)
    {
       cout << s << " ";
       newfile << s << "\n";
    };*/
    BaseWaveApplLayer::writeMessages();
}
